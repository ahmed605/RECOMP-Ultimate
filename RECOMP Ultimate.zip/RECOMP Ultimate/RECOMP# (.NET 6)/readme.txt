How to install:
- Enable Developer Mode
- Install .NET 6
- Run Install.cmd